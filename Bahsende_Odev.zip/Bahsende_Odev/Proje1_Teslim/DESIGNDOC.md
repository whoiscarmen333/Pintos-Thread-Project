+----------------------------------------------------------+
|         PİNTOS PROJESİ 1 — THREADS                      |
|         TASARIM BELGESİ (DESIGN DOCUMENT)                |
+----------------------------------------------------------+

---- GRUP ----

Adı Soyadı  <email@ogr.deu.edu.tr>
Adı Soyadı  <email@ogr.deu.edu.tr>
Adı Soyadı  <email@ogr.deu.edu.tr>


---- ÖN HAZIRLIKLAR ----

Bu projede Pintos işletim sistemi çekirdeği üzerinde üç temel görev
gerçekleştirilmiştir:

  (1) Alarm Saati — busy-waiting olmadan timer_sleep() yeniden implementasyonu
  (2) Öncelikli Zamanlama — öncelik bağışı (priority donation) ile birlikte
  (3) Gelişmiş Zamanlayıcı — 4.4BSD tabanlı MLFQS

Değişiklik yapılan dosyalar:
  devices/timer.c   — Alarm saati implementasyonu
  threads/thread.c  — Zamanlayıcı ve MLFQS güncellemeleri
  threads/thread.h  — Yeni struct alanları ve sabit nokta makroları
  threads/synch.c   — Öncelik bağışlı kilit/semafor/koşul değişkeni

Başvurulan kaynaklar (ders materyalleri dışında):
  - Pintos Resmi Dokümantasyonu (Stanford Üniversitesi)
  - Operating System Concepts — Silberschatz, Galvin, Gagne (10. Baskı)
  - 4.4BSD Zamanlayıcı Spesifikasyonu (Pintos Dökümantasyonu, Bölüm B)


==============================================================
                     A — ALARM SAATİ
==============================================================

---- VERİ YAPILARI ----

>> A1: Eklenen veya değiştirilen her struct üyesi, global/statik değişken
>>     ve typedef'in amacını 25 kelime veya daha azla açıklayın.

  [devices/timer.c]
  blockedThreads (struct list)
    Uyku moduna alınan thread'lerin tutulduğu bağlı liste.
    Timer kesmesi her tick'te bu listeyi tarayarak uyandırılacak
    thread'leri tespit eder.

  [threads/thread.h — struct thread]
  timeToWake (int64_t)
    Thread'in uyandırılması gereken mutlak zamanlayıcı tick değeri.
    timer_sleep() tarafından "şimdiki tick + bekleme süresi" olarak
    hesaplanıp atanır.


---- ALGORİTMALAR ----

>> A2: timer_sleep() çağrısında ve zamanlayıcı kesme işleyicisinde
>>     neler olduğunu adım adım açıklayın.

  timer_sleep(ticks) Çağrısı:

    Adım 1 — Mevcut thread pointer'ı ve güncel tick sayısı alınır.
    Adım 2 — Thread'in uyandırılma zamanı hesaplanır:
                  uyandırma_zamanı = şimdiki_tick + ticks
    Adım 3 — Kesmeler devre dışı bırakılır (kritik bölüm başlar).
    Adım 4 — Thread, "uyuyan thread'ler" listesine (blockedThreads) eklenir.
    Adım 5 — thread_block() çağrılır; thread BLOCKED durumuna geçer ve
              zamanlayıcı başka bir thread'i çalıştırır.
    Adım 6 — Thread uyandıktan sonra kesmeler geri açılır.

  Zamanlayıcı Kesme İşleyicisi (her tick'te çalışır):

    Adım 1 — Global tick sayacı bir artırılır.
    Adım 2 — thread_tick() çağrılarak istatistikler güncellenir.
    Adım 3 — blockedThreads listesi boşsa işlem yapılmadan çıkılır.
    Adım 4 — Liste baştan sona taranır:
                • Thread'in uyandırma zamanı ≤ şimdiki tick ise:
                    – Thread listeden çıkarılır.
                    – thread_unblock() ile hazır kuyruğuna eklenir.
                • Aksi hâlde bir sonraki thread'e geçilir.

  Sonuç: Thread belirlenen süre boyunca CPU kullanmadan bekler; işlemci
  bu sürede diğer thread'lere verilir (busy-waiting tamamen ortadan kalkar).


>> A3: Zamanlayıcı kesme işleyicisinde harcanan süreyi azaltmak için
>>     hangi önlemler alınmıştır?

  Önlem 1 — Erken Çıkış:
    blockedThreads listesi boşsa döngüye hiç girilmeden return yapılır.
    Uyuyan thread olmadığında ek maliyet sıfıra indirilir.

  Önlem 2 — Tek Geçişli Tarama:
    Liste yalnızca bir kez baştan sona taranır; iç içe döngü veya
    yeniden tarama yoktur (O(n) karmaşıklık).

  Önlem 3 — Verimli Eleman Kaldırma:
    list_remove(e) hem elemanı siler hem de bir sonraki elemanın
    pointer'ını döndürür; ekstra list_next() çağrısı gerekmez.

  Önlem 4 — Hafif thread_unblock():
    thread_unblock() yalnızca thread'i hazır kuyruğuna ekler; gerçek
    zamanlama kararı kesme işleyicisi bittikten sonra verilir.

  Önlem 5 — Basit Karşılaştırma:
    Kesme işleyicisinde yalnızca tam sayı karşılaştırması (≤) yapılır;
    kayan nokta veya ağır matematiksel işlem yoktur.


---- SENKRONİZASYON ----

>> A4: Birden fazla thread aynı anda timer_sleep() çağırırsa yarış
>>     koşulları nasıl önlenir?

  timer_sleep() içinde, liste ekleme (list_push_back) ve thread_block()
  işlemlerinden önce intr_disable() ile kesmeler kapatılır.

  Bu mekanizma:
    • Pintos tek işlemcili bir sistem olduğundan kesmeler kapalıyken
      gerçek anlamda eşzamanlılık oluşmaz.
    • İki thread'in aynı anda blockedThreads listesini değiştirerek
      liste tutarlılığını bozması engellenmiş olur.
    • thread_block() zaten kesmelerin kapalı olduğunu ASSERT ile zorunlu
      kılar; bu nedenle intr_disable() çağrısı kaçınılmazdır.

  intr_set_level(old) yalnızca thread uyandıktan sonra çağrılır; bu
  sayede "listeye eklendi ama henüz bloklanmadı" penceresinde başka
  bir thread müdahale edemez.


>> A5: timer_sleep() çağrılırken bir zamanlayıcı kesmesi gelirse yarış
>>     koşulları nasıl önlenir?

  timer_sleep() işlemi iki aşamadan oluşur:

  Aşama 1 — timeToWake ayarı (kesmeler henüz kapalı değil):
    Bu aşamada kesme gelse thread henüz blockedThreads listesinde
    değildir; kesme işleyicisi bu thread'i göremez, herhangi bir
    sorun oluşmaz. Thread, timer_sleep() içinde kaldığı yerden devam eder.

  Aşama 2 — intr_disable() sonrası liste ekleme + thread_block():
    Kesmeler kapalı olduğundan bu aşama hiçbir şekilde bölünemez.
    Liste değiştirme ve thread'i bloklama atomik olarak gerçekleşir.

  Sonuç: Thread ya hiç listede değildir (kesme onu görmez), ya da
  listede ve bloklanmıştır (kesme onu güvenle uyandırabilir). Bu iki
  durum arasındaki tehlikeli "yarı bölünmüş" durum yaşanamaz.


---- GEREKÇE ----

>> A6: Bu tasarımı neden seçtiniz? Alternatiflere kıyasla üstünlükleri
>>     nelerdir?

  Seçilen Tasarım:
    Ayrı bir "uyuyan thread'ler" listesi + her thread'de uyandırma zamanı

  Üstünlükleri:
    1. Busy-waiting tamamen ortadan kalkar; uyuyan thread CPU kullanmaz.
    2. Yalnızca iki küçük eklemeyle (bir liste, bir alan) minimal değişiklik
       yapılmıştır; Pintos'un mevcut altyapısıyla tam uyumludur.
    3. intr_disable() temelli senkronizasyon hem çoklu thread hem de
       kesme anı yarış koşullarını eksiksiz çözer.

  Değerlendirilen Alternatif — Sıralı Liste (uyandırma zamanına göre):
    Kesme işleyicisindeki O(n) taramayı iyileştirebilirdi. Ancak:
    • Ekleme maliyeti O(n)'e çıkar.
    • Pintos'ta uyuyan thread sayısı tipik olarak çok az olduğundan
      pratikte anlamlı bir fark yaratmaz.
    Bu nedenle sade olan sırasız liste tercih edilmiştir.


==============================================================
               B — ÖNCELİKLİ PLANLAMA
==============================================================

---- VERİ YAPILARI ----

>> B1: Eklenen veya değiştirilen her struct üyesi, global/statik değişken
>>     ve typedef'in amacını 25 kelime veya daha azla açıklayın.

  [threads/thread.h — struct thread]

  base_priority (int)
    Thread'in bağıştan bağımsız temel önceliği. Kilit bırakıldığında
    etkili öncelik bu değere geri döner.

  donators (struct list)
    Bu thread'e öncelik bağışlamış olan tüm thread'lerin listesi.
    Birden fazla eşzamanlı bağışı (multiple donation) izlemek için kullanılır.

  donor_elem (struct list_elem)
    Thread'in başka bir thread'in donators listesine girmesini sağlayan
    liste elemanı.

  locked_by (struct lock *)
    Thread'in şu anda beklediği kilide pointer (kilit yoksa NULL).
    İç içe bağış (nested donation) zinciri bu pointer üzerinden gezilir.

  [threads/synch.h — struct lock — değiştirilmedi, açıklama amaçlı]

  holder (struct thread *)
    Kilidi tutan thread'e pointer. Bağış hedefini bulmak için kullanılır.


>> B2: Öncelik bağışını izlemek için kullanılan veri yapısını açıklayın.
>>     İç içe bağışı ASCII diyagramla gösterin.

  Veri Yapısı:
    Her thread'in kendi donators listesi vardır. Bir thread kilidi
    beklemeye başladığında kendini kilit sahibinin donators listesine
    ekler. locked_by pointer'ı ise zincir boyunca yukarı gitmek için
    kullanılır. Kilit bırakıldığında yalnızca o kilitle ilişkili
    donators temizlenir; diğerleri korunur.

  İç İçe Bağış Örneği (3 seviye, maksimum derinlik = 8):

    Öncelikler: H=3 (yüksek), M=2 (orta), L=1 (düşük)
    H, lock_A için M'yi bekliyor.
    M, lock_B için L'yi bekliyor.

    BAĞIŞ ÖNCESİ:
    ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
    │  Thread H   │     │  Thread M   │     │  Thread L   │
    │ öncelik = 3 │     │ öncelik = 2 │     │ öncelik = 1 │
    │ bekliyor: A │     │ bekliyor: B │     │ bekliyor: - │
    └──────┬──────┘     └──────┬──────┘     └─────────────┘
           │                   │
           ▼                   ▼
       [Lock A]            [Lock B]
       tutucu: M           tutucu: L

    BAĞIŞ SONRASI (zincirleme yayılım):
    ┌─────────────┐     ┌──────────────────┐     ┌──────────────────┐
    │  Thread H   │     │   Thread M       │     │   Thread L       │
    │ öncelik = 3 │     │ öncelik = 3 ←    │     │ öncelik = 3 ←    │
    │             │     │ donators = [H]   │     │ donators = [M]   │
    └─────────────┘     └──────────────────┘     └──────────────────┘
                           ↑ H'den bağış            ↑ M aracılığıyla
                                                       H'den zincirleme

    Kilit zinciri bozulunca (L → lock_B bırakır → M alır → lock_A bırakır):
      Her kilit bırakıldığında o kilide ait donators temizlenir ve
      thread'in önceliği kalan bağışlara göre yeniden hesaplanır.


---- ALGORİTMALAR ----

>> B3: Bekleyen en yüksek öncelikli thread'in ilk uyandırılması nasıl
>>     sağlanır?

  Semafor (sema_down / sema_up):
    • sema_down: Beklemeye giren thread, waiters listesine öncelik
      sırasına göre (büyükten küçüğe) eklenir.
    • sema_up: Waiters listesi yeniden sıralanır (bir thread'in önceliği
      bağış nedeniyle değişmiş olabilir), ardından listenin önünden en
      yüksek öncelikli thread alınarak hazır kuyruğuna eklenir.
      Uyandırılan thread mevcut thread'den öncelikli ise hemen yield yapılır.

  Kilit (lock_acquire / lock_release):
    Kilitler semafor üzerine kurulduğundan aynı mekanizma geçerlidir.
    Öncelik bağışı ek olarak kilit sahibinin önceliğini yükseltir,
    böylece kilit mümkün olan en kısa sürede serbest bırakılır.

  Koşul Değişkeni (cond_wait / cond_signal):
    • cond_wait: Her bekleyen thread için ayrı bir semaphore_elem
      oluşturulur ve bu eleman, thread'in önceliğine göre cond->waiters
      listesine sıralı olarak eklenir.
    • cond_signal: Listenin önündeki (en yüksek öncelikli) semaphore_elem
      alınır ve ilgili semaforun sema_up'ı çağrılarak thread uyandırılır.


>> B4: lock_acquire() öncelik bağışı oluşturduğunda olaylar nasıl gelişir?
>>     İç içe bağış nasıl işlenir?

  Olaylar Sırası:

    1. Kilit başka bir thread tarafından tutuluyor mu kontrol edilir.

    2. Tutuluyorsa:
         a. Bekleyen thread'in "beklediği kilit" alanı güncellenir.
         b. Bekleyen thread, kilit sahibinin donators listesine eklenir.

    3. İç içe bağış zinciri gezilir (en fazla 8 seviye):
         • Bekleyen thread'in önceliği, kilit sahibinin önceliğinden
           yüksekse kilit sahibinin önceliği yükseltilir.
         • Kilit sahibi de başka bir kilidi bekliyorsa aynı adım
           o kilidin sahibi için tekrarlanır.
         • Zincir kırıldığında (öncelik yükseltme gerekmediğinde) durulur.

    4. sema_down ile kilit müsait olana kadar beklenir (thread bloke olur).

    5. Kilit alındıktan sonra thread kilit sahibi olarak atanır ve
       "beklediği kilit" alanı temizlenir.


>> B5: lock_release() yüksek öncelikli bir waiter varken çağrılırsa
>>     olaylar nasıl gelişir?

  Olaylar Sırası:

    1. Kilit sahibi temizlenir (holder = NULL).

    2. sema_up çağrılır: Bekleyen en yüksek öncelikli thread hazır
       kuyruğuna eklenir. Uyandırılan thread mevcut thread'den öncelikliyse
       bu adımda hemen yield tetiklenebilir.

    3. MLFQS modu aktifse bağış işlemi yapılmadan çıkılır.

    4. Mevcut thread'in donators listesi taranır:
         • Bu kilidi bekleyen donators listeden çıkarılır.
         • Başka kilitler için bekleyen donators'ların en yüksek önceliği
           kaydedilir.

    5. Öncelik güncellenir:
         • Başka donator kaldıysa → mevcut öncelik = max(temel öncelik,
           kalan en yüksek bağış).
         • Donator kalmadıysa → öncelik, temel önceliğe döner.

    6. Öncelik düştüyse thread_yield() çağrılarak daha öncelikli thread
       çalışmaya başlar.


---- SENKRONİZASYON ----

>> B6: thread_set_priority() içindeki olası yarış koşulunu açıklayın.
>>     Bunu engellemek için kilit kullanılabilir mi?

  Olası Yarış Koşulu:
    thread_set_priority() yürütülürken başka bir thread bu thread'e
    öncelik bağışı yapabilir. Örneğin:

      • thread_set_priority() "donators listesi boş" okur.
      • Bu anda timer kesmesi gelir: başka thread, donators listesine
        eklenir ve bu thread'in önceliği yükseltilir.
      • thread_set_priority() çalışmaya döner ve önceliği new_priority
        olarak üzerine yazar → yeni bağış kaybolur.

  Mevcut Çözüm:
    donators listesi boşsa hem temel hem etkili öncelik güncellenir.
    Doluysa yalnızca temel öncelik güncellenir; etkili öncelik korunur.
    Bu mantık büyük ölçüde doğrudur; ancak yukarıdaki ince yarış
    koşuluna karşı tam güvence için intr_disable() eklenmesi önerilir.

  Kilit Kullanılabilir mi?
    HAYIR. Kilit kullanılması şu sorunlara yol açar:
      • Kilit almak thread'i uyutabilir; oysa bu işlem kesme-bağımlı
        zamanlama değişikliklerinde de çağrılır.
      • Kilit almaya çalışan thread bağış zinciriyle kilitlenme
        (deadlock) yaratabilir.
    En doğru çözüm yine intr_disable() / intr_set_level() kullanmaktır.


---- GEREKÇE ----

>> B7: Bu tasarımı neden seçtiniz? Alternatiflere kıyasla üstünlükleri?

  Seçilen Tasarım: donators listesi + locked_by pointer'ı + base_priority

  Üstünlükleri:

    1. Birden Fazla Eşzamanlı Bağış (Multiple Donation):
       donators listesi, aynı anda birden fazla thread'den bağış
       alınmasını doğal biçimde destekler. Kilit bırakıldığında yalnızca
       o kilide ait bağışlar temizlenir; diğerleri bozulmaz.

    2. İç İçe Bağış (Nested Donation):
       locked_by pointer'ı ayrı bir "bekleme grafiği" veri yapısına
       gerek kalmadan zincir boyunca gezinmeyi sağlar.

    3. Güvenli Öncelik Geri Dönüşü:
       base_priority alanı kilit bırakıldıktan sonra orijinal önceliğe
       dönüşü garanti eder; kalan bağışlar da doğru şekilde hesaplanır.

    4. Düşük Bellek Maliyeti:
       Her thread'e eklenen alan yalnızca bir liste başı, bir liste
       elemanı, bir pointer ve bir tam sayı kadardır.

  Reddedilen Alternatif — Öncelik Yığını (Stack):
    Her bağışta push, bırakırken pop yapılabilirdi. Ancak hangi bağışın
    hangi kilide ait olduğu izlenemeyeceğinden birden fazla kilit
    durumunda öncelik yanlış hesaplanırdı.

  Reddedilen Alternatif — Tek Maksimum Değer:
    Donators listesi yerine tek bir "en yüksek bağışlanan öncelik"
    saklanabilirdi. Fakat aynı nedenle (bağış-kilit eşleşmesi
    izlenemiyor) kilit bırakıldıktan sonra öncelik hatalı olurdu.


==============================================================
                C — GELİŞMİŞ PLANLAMA (MLFQS)
==============================================================

---- VERİ YAPILARI ----

>> C1: Eklenen veya değiştirilen her struct üyesi, global/statik değişken,
>>     typedef ve makronun amacını 25 kelime veya daha azla açıklayın.

  [threads/thread.h — struct thread]

  nice (int)
    Thread'in "nezaket" değeri. Pozitif değer önceliği düşürür,
    negatif değer artırır. Başlangıçta 0; ebeveyn thread'den miras alınır.

  recent_cpu (int — 17.14 sabit nokta biçimi)
    Thread'in son zamanlarda kullandığı CPU süresinin ölçümü.
    Her tick'te çalışan thread için 1 artırılır; üstel ortalama ile
    yeni değerler hesaplanır.

  [threads/thread.c — global]

  load_avg (int — 17.14 sabit nokta biçimi)
    Sistemin son dakikalar içindeki ortalama hazır (runnable) thread
    sayısı. Her saniyede (TIMER_FREQ tick) üstel ortalama ile güncellenir.

  [threads/thread.h — struct thread]

  all_elem (struct list_elem)
    Thread'in all_threads listesindeki liste elemanı. MLFQS güncellemeleri
    bu liste üzerinden tüm thread'lere uygulanır.

  [threads/thread.c — global]

  all_threads (static struct list)
    Sistemdeki tüm aktif thread'lerin listesi. Öncelik ve recent_cpu
    güncellemeleri bu liste gezilerek yapılır.

  [threads/thread.h — Sabit Nokta Aritmetiği Makroları]

  Makro Adı        Açıklama
  ───────────────────────────────────────────────────────────
  F                Ölçek çarpanı: 2^14 = 16384 (17.14 biçimi)
  TOFIXED(n)       Tam sayıyı sabit noktaya çevirir
  TOINTZERO(x)     Sabit noktayı sıfıra yuvarlayarak tam sayıya çevirir
  TOINTNEAREST(x)  Sabit noktayı en yakın tam sayıya yuvarlar
  ADD(x,y)         İki sabit nokta toplar
  SUB(x,y)         İki sabit nokta çıkarır
  ADDXN(x,n)       Sabit noktaya tam sayı ekler
  SUBXN(x,n)       Sabit noktadan tam sayı çıkarır
  MULTXY(x,y)      İki sabit noktayı çarpar (int64_t ara hesap)
  MULTXN(x,n)      Sabit nokta ile tam sayı çarpar
  DIVXY(x,y)       İki sabit noktayı böler (int64_t ara hesap)
  DIVXN(x,n)       Sabit noktayı tam sayıya böler


---- ALGORİTMALAR ----

>> C2: A, B, C thread'lerinin nice değerleri sırasıyla 0, 1, 2 ve
>>     recent_cpu değerleri başlangıçta 0'dır. Tabloyu doldurun.

  Kullanılan Formül:
    priority = 63 - (recent_cpu / 4) - (2 × nice)

  Not: recent_cpu yalnızca çalışan thread için her tick'te 1 artar.
       Öncelik her 4 tick'te yeniden hesaplanır.
       load_avg etkisi ilk 100 tick'te ihmal edilebilir düzeydedir.

  ┌───────┬────────────────────┬────────────────────┬──────────┐
  │ Tick  │    recent_cpu      │     priority       │ Çalışan  │
  │       │  A     B     C     │  A     B     C     │ Thread   │
  ├───────┼──────┬─────┬───────┼──────┬─────┬───────┼──────────┤
  │   0   │  0   │  0  │   0   │  63  │ 61  │  59   │    A     │
  │   4   │  4   │  0  │   0   │  62  │ 61  │  59   │    A     │
  │   8   │  8   │  0  │   0   │  61  │ 61  │  59   │    B     │
  │  12   │  8   │  4  │   0   │  61  │ 60  │  59   │    A     │
  │  16   │ 12   │  4  │   0   │  60  │ 60  │  59   │    B     │
  │  20   │ 12   │  8  │   0   │  60  │ 59  │  59   │    A     │
  │  24   │ 16   │  8  │   0   │  59  │ 59  │  59   │    C     │
  │  28   │ 16   │  8  │   4   │  59  │ 59  │  58   │    B     │
  │  32   │ 16   │ 12  │   4   │  59  │ 58  │  58   │    A     │
  │  36   │ 20   │ 12  │   4   │  58  │ 58  │  58   │    C     │
  └───────┴──────┴─────┴───────┴──────┴─────┴───────┴──────────┘

  Seçilmiş Satırların Hesabı:

  Tick 0:
    A = 63 - 0/4 - 2×0 = 63  →  B = 63 - 0 - 2 = 61  →  C = 63 - 0 - 4 = 59
    En yüksek öncelik A → A çalışır.

  Tick 4 (A 4 tick çalıştı → A.recent_cpu = 4):
    A = 63 - 1 - 0 = 62  →  B = 61  →  C = 59
    A > B, A çalışmaya devam eder.

  Tick 8 (A 4 tick daha çalıştı → A.recent_cpu = 8):
    A = 63 - 2 - 0 = 61  →  B = 61  →  C = 59
    A ve B eşit. A zaman dilimini doldurdu (time slice bitti), B hazır
    listede daha önce; B çalışır.

  Tick 12 (B 4 tick çalıştı → B.recent_cpu = 4):
    A = 63 - 2 - 0 = 61  →  B = 63 - 1 - 2 = 60  →  C = 59
    A > B → A çalışır.

  Tick 16 (A 4 tick çalıştı → A.recent_cpu = 12):
    A = 63 - 3 - 0 = 60  →  B = 60  →  C = 59
    Eşit. A time slice bitti; B hazır listede daha önce → B çalışır.

  Tick 20 (B 4 tick çalıştı → B.recent_cpu = 8):
    A = 60  →  B = 63 - 2 - 2 = 59  →  C = 59
    A > B,C → A çalışır.

  Tick 24 (A 4 tick çalıştı → A.recent_cpu = 16):
    A = 63 - 4 - 0 = 59  →  B = 59  →  C = 59
    Üçü eşit. A time slice bitti; hazır listede [C(59), B(59)] sırası;
    C en uzun bekleyen → C çalışır.

  Tick 28 (C 4 tick çalıştı → C.recent_cpu = 4):
    A = 59  →  B = 59  →  C = 63 - 1 - 4 = 58
    Hazır liste: [B(59), A(59)] → B çalışır.

  Tick 32 (B 4 tick çalıştı → B.recent_cpu = 12):
    A = 59  →  B = 63 - 3 - 2 = 58  →  C = 63 - 1 - 4 = 58
    Hazır liste: [A(59), C(58), B(58)] → A çalışır.

  Tick 36 (A 4 tick çalıştı → A.recent_cpu = 20):
    A = 63 - 5 - 0 = 58  →  B = 58  →  C = 58
    Üçü eşit. Hazır liste: [C(58), B(58)] → C çalışır.


>> C3: Spesifikasyondaki herhangi bir belirsizlik tablonun değerlerini
>>     belirsiz kıldı mı? Hangi kuralı uyguladınız?

  Belirsizlik:
    Eşit öncelikli thread'ler arasında hangisinin çalışacağı spesifikasyonda
    açıkça tanımlanmamıştır. Bu durum tabloda Tick 8, 16, 24 ve 36'da
    ortaya çıkar.

  Uygulanan Kural — Round-Robin (FIFO):
    Bir thread zaman dilimini doldurunca (TIME_SLICE = 4 tick) hazır
    kuyruğuna eklenir. Kullandığımız liste ekleme fonksiyonu STRICT büyüktür
    (>) karşılaştırması yaptığından eşit öncelikli thread'ler listenin
    sonuna eklenir. Böylece en uzun bekleyen eşit-öncelikli thread her
    zaman önce seçilir.

  Uyumluluk:
    Bu kural, uygulamadaki thread_yield() ve thread_unblock() davranışıyla
    tam olarak örtüşmektedir; eşit öncelikli thread'ler arasında
    starvation (açlık) oluşmaz.


>> C4: Zamanlama işi kesme bağlamı ile dışarısı arasında nasıl
>>     bölündü? Performansa etkisi nedir?

  Kesme Bağlamında Yapılan İşler (timer_interrupt → thread_tick):

    Her tick (O(1)):
      • Çalışan thread'in recent_cpu değeri 1 artırılır.
      • idle thread kontrolü yapılır.

    Her 4 tick'te (O(n)):
      • Tüm thread'lerin öncelikleri all_threads listesi gezilerek
        yeniden hesaplanır.

    Her 100 tick'te (O(n)):
      • Sistem genelinde load_avg güncellenir.
      • Tüm thread'lerin recent_cpu değerleri yeniden hesaplanır.

  Kesme Bağlamı Dışında Yapılan:
    • thread_set_nice(): Kullanıcı çağrısıyla nice ve öncelik güncellenir,
      gerekirse yield yapılır.

  Performans Değerlendirmesi:

    Avantaj:
      Öncelikler kesme bağlamında önceden hesaplandığından bir thread
      zamanlanmaya hazır olduğunda önceliği zaten günceldir; zamanlama
      kararı O(1)'dir.

    Dezavantaj:
      Thread sayısı (n) arttıkça her 4 tick'teki O(n) döngüsü timer
      kesme işleyicisini uzatır:
        (a) Kesme işleyicisi çalıştığında işlemci resmi olarak mevcut
            thread'in "üzerinde" çalışır; bu thread gerçekte kullandığından
            fazla recent_cpu biriktirir ve önceliği haksız yere düşer.
        (b) Kesme gecikmesi artar, gerçek zamanlı tepki yavaşlar.

    Olası İyileştirme:
      Yalnızca aktif (çalışan + hazır) thread'lerin öncelikleri
      güncellense bloklu thread'ler için boşuna işlem yapılmaz.


---- GEREKÇE ----

>> C5: Tasarımınızı eleştirin: avantajlar, dezavantajlar ve olası
>>     iyileştirmeler.

  Avantajlar:

    1. Sadelik: recent_cpu, nice ve load_avg doğrudan struct thread ve
       global değişkende tutulur; ek karmaşık veri yapısına gerek yoktur.

    2. Doğruluk: Sabit nokta makroları kayan nokta kullanmadan kesirli
       hesaplama sağlar; çekirdek ortamında zorunlu olan bu gereksinimi
       karşılar.

    3. İki Mod Desteği: thread_mlfqs bayrağıyla öncelikli zamanlayıcı
       ve MLFQS aynı kod tabanında tutulur; geçiş tek bir koşul
       denetiminden ibarettir.

    4. Spesifikasyona Birebir Uyum: Formüller 4.4BSD belgesindeki
       tanımlara eksiksiz uymaktadır.

  Dezavantajlar:

    1. O(n) Kesme İşleyicisi: Her 4 tick'te n thread'in önceliğinin
       güncellenmesi büyük sistemlerde ölçeklenmez.

    2. Öncelik Bağışı ile Çatışma: MLFQS aktifken bağış tamamen
       devre dışı kalır; gerçek sistemlerde ikisi birlikte işlev
       görebilmelidir.

    3. Ufak Yuvarlama Sapmaları: Büyük recent_cpu değerlerinde 17.14
       sabit nokta biçiminin sınırlı hassasiyeti yüzünden çok küçük
       sapmalar birikebilir.

  İyileştirme Önerileri:

    1. 64 Ayrı Kuyruk: Her öncelik seviyesi için bir liste tutulsa
       zamanlama kararı O(1) olur.

    2. Geç (Lazy) Hesaplama: Öncelikler yalnızca thread hazır kuyruğuna
       girerken hesaplansa bloklu thread'ler için gereksiz işlem yapılmaz.

    3. Atomik thread_set_priority: B6'da tanımlanan ince yarış koşulunu
       kapatmak için intr_disable() / intr_set_level() eklenmelidir.


>> C6: Sabit nokta matematiğini nasıl uyguladınız ve neden bu yöntemi
>>     seçtiniz?

  Seçilen Yöntem: thread.h dosyasında #define makro seti

  Bu Yöntemin Seçilme Nedenleri:

    1. Sıfır Çalışma Zamanı Maliyeti:
       Makrolar derleme zamanında yerine konulur; fonksiyon çağrısı
       yükü oluşmaz. Her timer tick'inde çağrılan hesaplamalar için
       bu kritik önem taşır.

    2. Okunabilirlik:
       MULTXY, DIVXY, ADDXN gibi isimler ham aritmetik ifadelerine kıyasla
       kodun anlaşılmasını kolaylaştırır ve hata riskini azaltır.

    3. Tek Tanım Noktası:
       17.14 biçiminin ölçek faktörü (F = 2^14) yalnızca bir yerde
       tanımlanır. Biçim değiştirilmek istenirse yalnızca F güncellenir.

    4. Taşma Önlemi:
       Çarpma ve bölme işlemlerinde (MULTXY, DIVXY) hesaplama öncesi
       int64_t dönüşümü yapılarak iki büyük sabit nokta değerinin
       çarpımında oluşabilecek 32-bit taşması önlenir.

  Neden Typedef + Satır İçi Fonksiyon Değil?
    Bu alternatif tip güvenliği sağlardı; ancak Pintos'un C99 ortamında
    inline fonksiyonların taşınabilirliği kesin değildir. Makroların
    sunduğu sıfır maliyet garantisini de veremez.

  Neden Soyutlama Katmanı Gerekli?
    Sabit nokta hesaplamaları birden fazla yerde kullanılmaktadır
    (thread_tick, thread_set_nice, thread_get_recent_cpu,
    thread_get_load_avg). Merkezi bir soyutlama olmadan aynı F
    sabit değeri ve uzun aritmetik ifadeler her yerde tekrarlanır;
    hem bakım güçleşir hem de hata olasılığı artar.
