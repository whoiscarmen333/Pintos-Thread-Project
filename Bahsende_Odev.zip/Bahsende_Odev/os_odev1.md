---- GRUP ----

>> Grup üyelerinizin adlarını ve e-posta adreslerini doldurun.

Adı Soyadı <email@ogr.deu.edu.tr>  
Adı Soyadı <email@ogr.deu.edu.tr>  
Adı Soyadı <email@ogr.deu.edu.tr>

---- ÖN HAZIRLIKLAR ----

>> Teslimatınızla ilgili herhangi bir ön hazırlık yorumunuz varsa lütfen burada belirtin.

Bu projede Pintos işletim sistemi çekirdeği üzerinde üç temel görev gerçekleştirilmiştir:
(1) Alarm saatinin busy-waiting olmaksızın yeniden implementasyonu,
(2) Öncelikli zamanlama ve öncelik bağışı mekanizması,
(3) 4.4BSD tabanlı çok seviyeli geri besleme kuyruk zamanlayıcısı.

Implementasyonlar, threads/thread.c, threads/thread.h, threads/synch.c ve
devices/timer.c dosyalarında gerçekleştirilmiştir. Sabit nokta aritmetiği
için gerekli makrolar thread.h dosyasına eklenmiştir.

>> Pintos dokümantasyonu, ders kitabı, ders notları dışında, teslimatınızı hazırlarken başvurduğunuz çevrimdışı veya çevrimiçi kaynakları belirtiniz.

- Pintos Resmi Dokümantasyonu (Stanford): https://web.stanford.edu/class/cs140/projects/pintos/pintos.html
- Operating System Concepts (Silberschatz, Galvin, Gagne), 10. Baskı
- 4.4BSD Scheduler Spesifikasyonu (Bölüm B - Pintos Dökümantasyonu)


                 ALARM SAATİ
                 ===========

---- VERİ YAPILARI ----

>> A1: Her yeni veya değiştirilen `struct` veya `struct` üyesi, global veya statik değişken,
>>     `typedef` veya enumerasyonun beyanını buraya kopyalayın. Her birinin amacını 25 kelime
>>     veya daha az bir şekilde tanımlayın.

/* devices/timer.c */
static struct list blockedThreads;
  → Uyuyan (bloklanmış) thread'lerin tutulduğu bağlı liste.
    Timer kesmesi bu listeyi tarayarak uyandırılacak thread'leri belirler.

/* threads/thread.h — struct thread içine eklendi */
int64_t timeToWake;
  → Thread'in uyandırılması gereken mutlak timer tick değeri.
    timer_sleep() tarafından ayarlanır; timer kesmesi bu değeri kontrol eder.


---- ALGORİTMALAR ----

>> A2: timer_sleep() fonksiyonuna yapılan bir çağrıda neler olduğunu,
>>     zamanlayıcı kesme işleyicisinin etkilerini kısaca açıklayın.

timer_sleep(ticks) Çağrısı:
1. Mevcut thread'e ait pointer alınır (thread_current()).
2. Mevcut zamanlayıcı tick sayısı okunur: start = timer_ticks().
3. Thread'in uyandırılma zamanı hesaplanıp kaydedilir:
       current->timeToWake = start + ticks
4. Kesmeleri devre dışı bırakmak için intr_disable() çağrılır.
5. Thread, blockedThreads listesine eklenir (list_push_back).
6. thread_block() çağrılarak thread THREAD_BLOCKED durumuna geçirilir
   ve zamanlayıcı bir sonraki çalışabilir thread'i seçer.
7. Thread tekrar uyandığında intr_set_level(old) ile kesmeler geri açılır.

Zamanlayıcı Kesme İşleyicisi (timer_interrupt):
1. Global ticks sayacı bir artırılır: ticks++.
2. thread_tick() çağrılarak istatistikler güncellenir.
3. blockedThreads listesi boşsa erken çıkılır (optimizasyon).
4. Liste başından sonuna kadar taranır:
     - Her thread için: temp->timeToWake <= ticks koşulu kontrol edilir.
     - Koşul sağlanıyorsa thread listeden çıkarılır (list_remove),
       timeToWake sıfırlanır ve thread_unblock(temp) ile hazır kuyruğuna
       eklenir.
     - Koşul sağlanmıyorsa bir sonraki elemana geçilir.

Bu sayede thread, belirlenen süre dolana kadar CPU kullanmadan bekler
(busy-waiting yok); CPU diğer thread'lere verilir.


>> A3: Zamanlayıcı kesme işleyicisi içinde harcanan süreyi minimize etmek
>>     için hangi adımlar atılmaktadır?

1. Liste Boşluk Kontrolü: blockedThreads listesi boşsa, döngüye hiç
   girilmeden hemen return yapılır. Bu, uyuyan thread olmadığında
   kesme işleyicisini neredeyse sıfır ek yük ile çalıştırır.

2. Tek Geçişli Tarama: Liste yalnızca bir kez baştan sona taranır;
   iç içe döngü veya yeniden tarama yoktur (O(n) karmaşıklık).

3. list_remove Döndürülen Pointer Kullanımı: list_remove(e), kaldırılan
   elemanın sonrasındaki elemanı döndürür; bu sayede ek list_next()
   çağrısı gerekmez.

4. thread_unblock'un Hafif Yapısı: thread_unblock() yalnızca thread'i
   hazır kuyruğuna (ready_list) ekler; zamanlama kararı
   schedule()/intr_yield_on_return() üzerinden daha sonra verilir.

5. Sabit Nokta Hesapları Dışarıda: Alarm clock için kesme işleyicisinde
   herhangi bir kayan nokta veya ağır matematiksel işlem yapılmaz;
   yalnızca tam sayı karşılaştırması (<=) kullanılır.


---- SENKRONİZASYON ----

>> A4: Birden fazla iş parçacığı aynı anda timer_sleep() fonksiyonunu
>>     çağırdığında yarış koşulları nasıl engellenir?

timer_sleep() fonksiyonu içinde, blockedThreads listesine ekleme
(list_push_back) ve thread_block() çağrısı yapılmadan önce
intr_disable() ile kesmeler devre dışı bırakılır. Bu:

- Aynı anda yalnızca bir thread'in kritik bölümde çalışmasını sağlar
  (Pintos tek işlemcili olduğundan kesmelerin kapatılması yeterlidir).
- Farklı thread'lerin aynı anda list_push_back yaparak liste tutarlılığını
  bozması engellenir.
- thread_block() fonksiyonu da ASSERT ile kesmelerin kapalı olduğunu doğrular,
  yani zaten intr_disable() zorunludur.

intr_set_level(old) ile kesmeler yalnızca thread uyandıktan sonra (yani
thread_block() dönüşünün ardından) geri açılır.


>> A5: timer_sleep() fonksiyonu çağrıldığında bir zamanlayıcı kesmesi
>>     meydana gelirse yarış koşulları nasıl engellenir?

timer_sleep() üç aşamadan oluşur:

Aşama 1 — timeToWake ayarlanır (henüz kesme kapalı değil):
  Bu aşamada kesme gelirse, thread henüz blockedThreads listesinde
  değildir. Kesme işleyicisi bu thread'i göremez; bir sorun olmaz.
  Thread, timer_sleep()'e döndüğünde kaldığı yerden devam eder.

Aşama 2 — intr_disable() çağrısının ardından liste ekleme + thread_block():
  Bu noktadan itibaren hiçbir kesme gelemez. Listenin değiştirilmesi
  ve thread'in bloklanması atomik olarak gerçekleşir.

Böylece "thread listeye eklendi ama henüz bloklanmadı" durumunda kesme
gelmesi ihtimali ortadan kalkar; thread ya henüz listede değildir
(dolayısıyla kesme onu görmez) ya da listede ve bloklanmıştır
(kesme onu doğru şekilde uyandırabilir).


---- GEREKÇE ----

>> A6: Bu tasarımı neden seçtiniz? Diğer düşündüğünüz tasarımlara kıyasla
>>     hangi açılardan daha üstün olduğunu düşünüyorsunuz?

Seçilen Tasarım: Ayrı bir blockedThreads listesi + timeToWake alanı

Üstünlükleri:

1. Busy-waiting yok: Orijinal implementasyonun tersine, uyuyan thread
   CPU kullanmaz; işlemci diğer thread'lere tamamen devredilir.

2. Sade ve anlaşılır: Eklenen iki yapı (bir liste + bir tam sayı alanı)
   ile minimal değişiklik yapılmıştır.

3. Eksiksiz senkronizasyon: Kesme devre dışı bırakma mekanizması,
   hem birden fazla thread'in aynı anda uyuması hem de kesme anındaki
   yarış koşullarını güvenli biçimde çözer.

Değerlendirilen Alternatif — Sıralı liste (timeToWake'e göre):
  Kesme işleyicisindeki O(n) taramayı, uyandırılacak süre gelene kadar
  listeye bakmayarak O(1)'e indirebilirdi. Ancak bu yaklaşım:
  - Ekleme maliyetini O(n)'e çıkarır,
  - Pintos'taki uygulamaların büyük çoğunluğunda uyuyan thread sayısı
    küçük olduğundan pratikte fark yaratmaz.

Bu nedenle daha basit olan sırasız liste tercih edilmiştir.


             ÖNCELİKLE PLANLAMA
             ===================

---- VERİ YAPILARI ----

>> B1: Her yeni veya değiştirilen `struct` veya `struct` üyesi, global veya statik değişken,
>>     `typedef` veya enumerasyonun beyanını buraya kopyalayın. Her birinin amacını 25 kelime
>>     veya daha az bir şekilde tanımlayın.

/* threads/thread.h — struct thread içine eklendi */

int base_priority;
  → Thread'in bağıştan bağımsız temel (orijinal) önceliği.
    Kilit bırakıldığında öncelik bu değere geri döner.

struct list donators;
  → Bu thread'e öncelik bağışlayan tüm thread'lerin listesi.
    Birden fazla eş zamanlı bağışı (multiple donation) izlemek için kullanılır.

struct list_elem donor_elem;
  → Thread'in başka bir thread'in donators listesine girmesi için liste elemanı.

struct lock *locked_by;
  → Thread'in şu anda beklediği kilit (yoksa NULL).
    İç içe bağış (nested donation) zinciri bu pointer üzerinden gezilir.

/* threads/synch.h — struct lock içinde zaten mevcut */
struct thread *holder;
  → Kilidi tutan thread pointer'ı. Bağış hedefini bulmak için kullanılır.


>> B2: Öncelik bağışını izlemek için kullanılan veri yapısını açıklayın.
>>     Bir iç içe bağışı ASCII sanatı ile diyagramlayın.

Veri Yapısı:
  Her thread'de bir `donators` listesi bulunur. Bir thread kilidi beklerken
  kendini kilit sahibinin donators listesine ekler (donor_elem aracılığıyla).
  `locked_by` pointer'ı ise zincir boyunca ilerlemek için kullanılır.
  Kilit serbest bırakıldığında, o kilide ait donators listeden temizlenir
  ve thread'in önceliği kalan en yüksek bağışa veya base_priority'ye döner.

İç İçe Bağış Örneği (3 seviye):

  Öncelikler: H=3 (yüksek), M=2 (orta), L=1 (düşük)
  H → lock_A bekliyor (M tutuyor)
  M → lock_B bekliyor (L tutuyor)

  BAŞLANGIÇ DURUMU:
  ┌───────────────┐        ┌───────────────┐        ┌───────────────┐
  │ Thread H      │        │ Thread M      │        │ Thread L      │
  │ priority = 3  │        │ priority = 2  │        │ priority = 1  │
  │ locked_by=A   │        │ locked_by=B   │        │ locked_by=NULL│
  └───────────────┘        └───────────────┘        └───────────────┘
         │ bekliyor                │ bekliyor
         ▼                         ▼
  ┌──────────┐              ┌──────────┐
  │  Lock A  │──holder──►  │  Lock B  │──holder──►  Thread L
  └──────────┘   (M)       └──────────┘   (L)
         │
         └── H, M'nin donators listesine eklenir → M.priority = 3
                                                     (H'nin priority'si)
             Zincir devam eder: M.locked_by = B, B.holder = L
             → L.priority = 3 (zincirleme / nested donation)

  BAĞIŞ SONRASI DURUM:
  ┌───────────────┐        ┌───────────────┐        ┌───────────────┐
  │ Thread H      │        │ Thread M      │        │ Thread L      │
  │ priority = 3  │        │ priority = 3  │        │ priority = 3  │
  │               │        │ donators=[H]  │        │ donators=[M]  │
  └───────────────┘        └───────────────┘        └───────────────┘

  L işini bitirip lock_B'yi bıraktığında:
    - M.donators'dan M'nin lock_B bekleyicileri çıkarılır
    - M önceliği kalan bağışlara göre yeniden hesaplanır (H hâlâ lock_A'yı bekliyor → M=3)
    - M çalışır, lock_B'yi alır, işini tamamlar, lock_A'yı bırakır
    - H kilidi alır, önceliği 3'te kalır (zaten kendi önceliği)


---- ALGORİTMALAR ----

>> B3: Bir kilit, semafor veya koşul değişkeni için bekleyen en yüksek
>>     öncelikli iş parçacığının ilk önce uyanmasını nasıl sağlarsınız?

Semafor (sema_down / sema_up):
  - sema_down: Beklemeye giren thread, sema->waiters listesine
    list_insert_ordered(..., comparePriorities) ile öncelik sırasında
    (azalan) eklenir.
  - sema_up: Listeyi list_sort ile yeniden sıralar (bir thread'in önceliği
    bağış yoluyla değişmiş olabilir), ardından list_pop_front ile en yüksek
    öncelikli thread'i çıkarır ve thread_unblock ile hazır kuyruğuna ekler.
    Eğer uyandırılan thread mevcut thread'den yüksek öncelikli ise
    thread_yield() çağrılır.

Kilit (lock_acquire / lock_release):
  - Kilitler semafor üzerine inşa edildiğinden aynı mekanizma geçerlidir.
  - Ek olarak öncelik bağışı sayesinde kilit sahibi thread önceliği yükseltilir,
    daha hızlı çalışır ve kilidi en kısa sürede bırakır.

Koşul Değişkeni (cond_wait / cond_signal):
  - cond_wait: Her bekleyen thread için ayrı bir semaphore_elem oluşturulur.
    Bu eleman, bekleyen thread'in önceliğine göre cond->waiters listesine
    sıralı olarak eklenir (öncelikten büyükten küçüğe sıralı yerleştirme).
  - cond_signal: cond->waiters listesinin önünden (en yüksek öncelikli
    semaphore_elem) alınır, o semaforun sema_up'ı çağrılarak thread uyandırılır.


>> B4: lock_acquire() fonksiyonu bir öncelik bağışı oluşturduğunda olaylar
>>     sırasını açıklayın. İç içe bağış nasıl işlenir?

Olaylar Sırası (lock_acquire):

1. Ön koşullar ASSERT ile doğrulanır (kilit NULL değil, kesme bağlamında değil,
   thread zaten kilidi tutmuyor).

2. Mevcut thread pointer'ı alınır: current = thread_current().

3. Kesmeler devre dışı bırakılır (intr_disable).

4. Kilit bağışı gerekip gerekmediği kontrol edilir (!thread_mlfqs koşulu):
   a. lock->holder != NULL ise (kilit başkasında):
      - current->locked_by = lock  (hangi kilidi beklediğini kaydet)
      - current, lock->holder->donators listesine eklenir (donor_elem ile).
      - İç İçe Bağış Zinciri (MAX_DEPTH=8'e kadar):
          temp = current
          while (temp->locked_by != NULL && depth < MAX_DEPTH):
            holder = temp->locked_by->holder
            if temp->priority > holder->priority:
              holder->priority = temp->priority  (önceliği yükselt)
              temp = holder                      (zincirde ilerle)
            else:
              break  (zincirde daha fazla yükseltmeye gerek yok)
   b. lock->holder == NULL ise: current->locked_by = NULL.

5. Kesmeler geri açılır (intr_set_level).

6. sema_down(&lock->semaphore): Kilit müsait olana kadar bloke ol.

7. Kilit alındıktan sonra: lock->holder = current.

İç İçe Bağış:
  Yukarıdaki while döngüsü, A→B→C→... şeklinde iç içe geçmiş bağış
  zincirlerini MAX_DEPTH derinliğine kadar yayar. Bu sayede en yüksek
  öncelikli thread'in önceliği tüm zincir boyunca aşağıya iletilir;
  hiçbir thread "öncelik tüneli" (priority inversion) nedeniyle aç
  kalmaz.


>> B5: lock_release() fonksiyonu, yüksek öncelikli bir iş parçacığının
>>     beklediği bir kilit üzerinde çağrıldığında olaylar sırasını açıklayın.

Olaylar Sırası (lock_release):

1. Ön koşullar doğrulanır (kilit NULL değil, kilidi tutan mevcut thread).

2. lock->holder = NULL  (kilit artık sahipsiz).

3. sema_up(&lock->semaphore): Bekleyen en yüksek öncelikli thread uyandırılır.
   - Bu thread hazır kuyruğuna (ready_list) eklenir.
   - Eğer uyandırılan thread'in önceliği mevcut thread'den yüksekse
     sema_up içindeki thread_yield() anında öncelik değişimine neden olur.

4. thread_mlfqs aktifse bağış işlemi yapılmaz (return).

5. Kesmeler devre dışı bırakılır (intr_disable).

6. Mevcut thread'in donators listesi taranır:
   - Eğer bir donator'ın locked_by == lock ise (bu kilit için bekliyordu):
       donator->locked_by = NULL yapılır ve listeden çıkarılır.
   - Diğer donator'ların (başka kilitler için bekleyenler) en yüksek
     önceliği m değişkeninde tutulur.

7. Öncelik güncellemesi:
   - Eğer başka donator kaldıysa:
       max(base_priority, m) → thread'in yeni önceliği olur.
   - Eğer hiç donator kalmadıysa:
       thread_set_priority(base_priority) çağrılır.

8. Öncelik düştüyse thread_yield() çağrılarak daha yüksek öncelikli
   thread çalışmaya başlar.

9. Kesmeler geri açılır.


---- SENKRONİZASYON ----

>> B6: thread_set_priority() fonksiyonunda potansiyel bir yarış koşulunu
>>     açıklayın ve uygulamanızın bunu nasıl engellediğini açıklayın.
>>     Bu yarış koşulunu engellemek için bir kilit kullanabilir misiniz?

Potansiyel Yarış Koşulu:
  thread_set_priority(new_priority) çağrısı sırasında, aynı thread başka
  bir thread tarafından öncelik bağışı alıyor olabilir. Örneğin:

  T1 (thread_set_priority çağırıyor):
      → list_empty(&current->donators) okur → BOŞ görür
      → [Kesme gelir: T2, T1'in donators listesine eklenir, T1.priority yükseltilir]
      → current->priority = new_priority  ← Bağışı siler!

  Bu durumda T1'in önceliği hatalı biçimde düşürülür ve öncelik bağışı
  kaybolur; T1 çalışmaya devam ettiğinde T2 aç kalabilir.

Mevcut Çözüm:
  thread_set_priority() içinde intr_disable()/intr_enable() kullanılmamıştır.
  Ancak Pintos'ta tek işlemcili ortamda, timer kesmesi thread_set_priority()
  içinde kesintiye yol açabilir. Güvenli implementasyon için intr_disable()
  eklenmesi önerilir.
  Mevcut kod, donators listesi boş ise base_priority ve priority'yi birlikte
  günceller; donators listesi doluysa yalnızca base_priority'yi günceller
  (etkili önceliği korur). Bu mantık büyük ölçüde doğrudur fakat yukarıdaki
  ince yarış koşuluna karşı tam koruma sağlamaz.

Kilit Kullanılabilir mi?
  HAYIR. thread_set_priority() bir kilit kullansaydı:
  - Kilit almak thread'i uyutabilir; oysa bu fonksiyon kesme bağlamında
    (örn. MLFQS güncellemesi sırasında) çağrılmamalıdır.
  - Kilidi almaya çalışan thread, bağış zinciriyle döngüye girebilir
    (deadlock riski).
  Bu nedenle en doğru çözüm intr_disable() / intr_set_level() kullanmaktır.


---- GEREKÇE ----

>> B7: Bu tasarımı neden seçtiniz? Diğer düşündüğünüz tasarımlara kıyasla
>>     hangi açılardan daha üstün olduğunu düşünüyorsunuz?

Seçilen Tasarım: donators listesi + locked_by pointer'ı + base_priority alanı

Üstünlükleri:

1. Birden Fazla Eş Zamanlı Bağış (Multiple Donation):
   donators listesi, bir thread'in birden fazla thread'den aynı anda
   bağış almasını doğal olarak destekler. Kilit bırakıldığında yalnızca
   o kilitle ilgili bağışlar temizlenir; diğerleri korunur.

2. İç İçe Bağış (Nested Donation):
   locked_by pointer'ı zincir boyunca gezinmeyi sağlar. Ayrı bir "bekleme
   grafiği" veri yapısına gerek yoktur; mevcut kilit/thread yapıları
   yeterlidir.

3. Öncelik Geri Dönüşü (Priority Restoration):
   base_priority alanı sayesinde kilit bırakıldıktan sonra orijinal önceliğe
   dönmek garantilenir; donators listesi başka bağışlar içeriyorsa bunlar
   da doğru biçimde hesaba katılır.

4. Düşük Bellek Maliyeti:
   Her thread'e eklenen alan yalnızca bir liste başı (donators), bir
   liste elemanı (donor_elem), bir pointer (locked_by) ve bir int
   (base_priority) kadardır.

Değerlendirilen Alternatif — Öncelik Değer Yığını (Stack):
  Her bağış alındığında öncelik bir yığına push, bırakıldığında pop
  yapılabilirdi. Ancak bu yaklaşım birden fazla kilidin bağımsız bağışlarını
  doğru şekilde yönetemez (hangi bağış hangi kilide aitti bilinemez).

Değerlendirilen Alternatif — Yalnızca Maksimum Öncelik Saklama:
  Donators listesi yerine tek bir "en yüksek bağışlanan öncelik" değeri
  tutulabilirdi. Fakat birden fazla kilit tutulduğunda hangi bağışın hangi
  kilitle ilişkili olduğu izlenemeyeceğinden, kilit bırakıldıktan sonra
  öncelik yanlış hesaplanırdı.

Bu gerekçelerle donators listesi tabanlı tasarım en doğru ve genişletilebilir
çözüm olarak seçilmiştir.


              GELİŞMİŞ PLANLAMA
              ==================

---- VERİ YAPILARI ----

>> C1: Her yeni veya değiştirilen `struct` veya `struct` üyesi, global veya statik değişken,
>>     `typedef` veya enumerasyonun beyanını buraya kopyalayın. Her birinin amacını 25 kelime
>>     veya daha az bir şekilde tanımlayın.

/* threads/thread.h — struct thread içine eklendi */

int nice;
  → Thread'in nice değeri. Önceliği azaltır (+) veya artırır (-).
    Başlangıçta 0; ebeveyn thread'den miras alınır.

int recent_cpu;
  → Thread'in son zamanlarda kullandığı CPU süresini gösteren sabit nokta
    değeri (17.14 biçimi). Her tick'te çalışan thread için 1 artırılır.

/* threads/thread.c — global değişken */
int load_avg;
  → Sistemin son dakikalar içindeki ortalama hazır thread sayısı.
    17.14 sabit nokta biçiminde saklanır. Her saniyede (TIMER_FREQ tick)
    güncellenir.

/* threads/thread.h — Sabit nokta aritmetiği makroları */
#define F           (1 << 14)
  → 17.14 sabit nokta biçimi için ölçek çarpanı (2^14 = 16384).

#define TOFIXED(n)  (n * F)
  → Tam sayıyı sabit noktaya çevirir.

#define TOINTZERO(x)    (x / F)
  → Sabit noktayı tam sayıya çevirir (sıfıra doğru yuvarlar).

#define TOINTNEAREST(x) ((x >= 0) ? ((x + F/2) / F) : ((x - F/2) / F))
  → Sabit noktayı en yakın tam sayıya yuvarlar.

#define ADD(x,y)    (x + y)          → İki sabit nokta sayısını toplar.
#define SUB(x,y)    (x - y)          → İki sabit nokta sayısını çıkarır.
#define ADDXN(x,n)  (x + n * F)      → Sabit noktaya tam sayı ekler.
#define SUBXN(x,n)  (x - n * F)      → Sabit noktadan tam sayı çıkarır.
#define MULTXY(x,y) (((int64_t)x) * y / F)  → İki sabit noktayı çarpar.
#define MULTXN(x,n) (x * n)          → Sabit nokta ile tam sayı çarpar.
#define DIVXY(x,y)  (((int64_t)x) * F / y)  → İki sabit noktayı böler.
#define DIVXN(x,n)  (x / n)          → Sabit noktayı tam sayıya böler.

/* threads/thread.c — all_threads listesi */
static struct list all_threads;
  → Sistemdeki tüm aktif thread'lerin listesi. MLFQS güncellemeleri
    sırasında recent_cpu ve öncelik hesaplamak için taranır.

/* threads/thread.h — struct thread */
struct list_elem all_elem;
  → Thread'in all_threads listesindeki list elemanı.


---- ALGORİTMALAR ----

>> C2: A, B ve C iş parçacıklarının nice değerleri sırasıyla 0, 1 ve 2.
>>     Her birinin recent_cpu değeri 0. Aşağıdaki tabloyu doldurun ve her
>>     bir iş parçacığı için her bir zamanlayıcı tikinden sonra yapılan
>>     planlama kararını, öncelik ve recent_cpu değerlerini gösterin:

Formüller:
  priority = PRI_MAX - (recent_cpu / 4) - (2 * nice)
           = 63      - (recent_cpu / 4) - (2 * nice)

  recent_cpu: Çalışan thread için her tick'te 1 artırılır.
  load_avg ve recent_cpu'nun tam güncellemesi her TIMER_FREQ=100 tick'te
  gerçekleşir; bu aralıkta olmadığından tabloda göz ardı edilmiştir.

timer  recent_cpu    priority   thread
ticks   A   B   C   A   B   C   to run
-----  --  --  --  --  --  --   ------
 0      0   0   0  63  61  59     A
 4      4   0   0  62  61  59     A
 8      8   0   0  61  61  59     B
12      8   4   0  61  60  59     A
16     12   4   0  60  60  59     B
20     12   8   0  60  59  59     A
24     16   8   0  59  59  59     C
28     16   8   4  59  59  58     B
32     16  12   4  59  58  58     A
36     20  12   4  58  58  58     C

Hesaplama Adımları (Seçilmiş Satırlar):

• Tick 0:  A=63-0-0=63, B=63-0-2=61, C=63-0-4=59  → A çalışır (max öncelik)
• Tick 4:  A 4 tick çalıştı → A.recent_cpu=4.
           A=63-1-0=62, B=61, C=59  → A çalışır
• Tick 8:  A 4 tick daha çalıştı → A.recent_cpu=8.
           A=63-2-0=61, B=61, C=59  → A time slice bitti, B hazır listede daha önce;
           eşit öncelikte B çalışır
• Tick 12: B 4 tick çalıştı → B.recent_cpu=4.
           A=61, B=63-1-2=60, C=59  → A çalışır (61 > 60)
• Tick 16: A 4 tick çalıştı → A.recent_cpu=12.
           A=63-3-0=60, B=60, C=59  → A time slice bitti; B hazır listede önceden var;
           eşit öncelikte B çalışır
• Tick 20: B 4 tick çalıştı → B.recent_cpu=8.
           A=60, B=63-2-2=59, C=59  → A çalışır (60 > 59)
• Tick 24: A 4 tick çalıştı → A.recent_cpu=16.
           A=63-4-0=59, B=59, C=59  → A time slice bitti; C en uzun bekleyen;
           hazır listede [C(59), B(59)], C çalışır
• Tick 28: C 4 tick çalıştı → C.recent_cpu=4.
           A=59, B=59, C=63-1-4=58  → Hazır liste: [B(59), A(59)]; B çalışır
• Tick 32: B 4 tick çalıştı → B.recent_cpu=12.
           A=59, B=63-3-2=58, C=58  → Hazır liste: [A(59), C(58)]; A çalışır
• Tick 36: A 4 tick çalıştı → A.recent_cpu=20.
           A=63-5-0=58, B=58, C=58  → Hazır liste: [C(58), B(58)]; C çalışır


>> C3: Planlayıcı spesifikasyonundaki herhangi bir belirsizlik tablodaki
>>     değerleri belirsiz hale getirdi mi? Eğer öyleyse, bunları çözmek
>>     için hangi kuralı kullandınız? Bu, planlayıcınızın davranışıyla uyumlu mu?

Belirsizlik: Eşit öncelikli thread'ler arasında hangisi çalışır?

Spesifikasyon, eşit öncelikli thread'ler arasındaki sıralamayı açıkça
tanımlamamaktadır. Bu durum tabloda birden fazla noktada ortaya çıkar
(tick 8, 16, 24, 36 gibi).

Kullanılan Kural: Round-Robin (FIFO sırası arasında döngüsel)
  - Bir thread zaman dilimini (time slice = 4 tick) doldurduğunda
    thread_yield() çağrısıyla ready_list'e eklenir.
  - list_insert_ordered kullanır ve comparePriorities fonksiyonu STRICT
    büyüktür (>) operatörü kullanır; bu nedenle eşit öncelikli thread'ler
    listenin sonuna eklenir (FIFO davranışı).
  - Böylece en uzun bekleyen eşit öncelikli thread önce çalışır.

Uyumluluk:
  Bu davranış implementasyonumuzla tam olarak uyumludur. thread_yield() ve
  thread_unblock() her ikisi de list_insert_ordered kullanır; eşit
  öncelikli thread mevcut eşitlerin arkasına gider. Bu sayede starvation
  (açlık) eşit öncelikli thread'ler arasında oluşmaz.


>> C4: Planlamayı kod içinde ve kesme bağlamı dışında yapılan işlerin
>>     maliyeti arasında nasıl böldüğünüz, performansı nasıl etkiler?

Kesme Bağlamında Yapılan İşler (timer_interrupt → thread_tick):

  Her Tick (O(1)):
    - Çalışan thread'in recent_cpu değeri 1 artırılır.
    - idle thread kontrolü yapılır.

  Her 4 Tick'te (O(n), n = toplam thread sayısı):
    - Tüm thread'lerin öncelikleri yeniden hesaplanır (all_threads taranır).
    - Bu, zaman dilimine (TIME_SLICE=4) eşit aralıklarla gerçekleşir.

  Her TIMER_FREQ=100 Tick'te (O(n)):
    - load_avg güncellenir.
    - Tüm thread'lerin recent_cpu değerleri güncellenir.

Kesme Bağlamı Dışında Yapılan İşler:
  - thread_set_nice(): nice değeri ayarlanır, öncelik yeniden hesaplanır,
    gerekirse yield yapılır. Kullanıcı çağrısıyla tetiklenir.

Performans Etkileri:

  Avantaj:
    - Öncelik hesaplamaları kesme bağlamında yapıldığından thread
      zamanlanmaya başladığında önceliği zaten güncellemiş olur;
      zamanlama kararı O(1)'dir (ready_list'in önünden al).

  Dezavantaj:
    - Çok sayıda thread (büyük n) varsa her 4 tick'teki O(n) döngüsü
      timer kesme işleyicisini uzatır. Bu durum:
      a) Çalışan thread'in gerçekten kullandığından daha fazla
         recent_cpu biriktirmiş gibi görünmesine yol açar (kesme
         işleyicisi o thread'in "üstünde" çalışır).
      b) Gerçek zamanlı tepkiyi yavaşlatabilir.
      c) Kesme gecikmesini (interrupt latency) artırır.

  Alternatif Yaklaşım:
    Yalnızca çalışan ve hazır kuyruğundaki thread'lerin öncelikleri
    güncellense (bloklu thread'ler atlanabilir), n sabit kalsa bile
    döngü daha kısa olurdu. Ancak bu optimizasyon implementasyonu
    karmaşıklaştırır.


---- GEREKÇE ----

>> C5: Tasarımınızı kısaca eleştirin, tasarım seçimlerinizdeki avantajları
>>     ve dezavantajları belirtin. Bu kısmı üzerinde daha fazla zaman
>>     harcayabilseydiniz, tasarımınızı nasıl geliştirmek veya iyileştirmek
>>     isterdiniz?

Avantajlar:

1. Sadelik: recent_cpu, nice ve load_avg değerleri doğrudan struct thread
   ve global değişkende tutulur; ek veri yapısı gerekmez.

2. Doğruluk: Sabit nokta makroları, kayan nokta sayısı kullanmadan
   kesirli hesaplamalara olanak tanır; bu Pintos çekirdeği için zorunludur.

3. Esneklik: thread_mlfqs bayrağı ile iki zamanlayıcı (öncelikli + MLFQS)
   arasında geçiş yapılabilir; aynı kod tabanı her ikisini destekler.

4. Spesifikasyona Uygunluk: Formüller (recent_cpu, load_avg, öncelik)
   4.4BSD belgesindeki tanımlara birebir uymaktadır.

Dezavantajlar:

1. O(n) Kesme İşleyicisi: Her 4 tick'te tüm thread'lerin önceliklerinin
   güncellenmesi, thread sayısı arttıkça ölçeklenmez.

2. Kayan Nokta Hassasiyeti Yok: 17.14 sabit nokta biçimi yeterli
   hassasiyette olsa da büyük recent_cpu değerlerinde yuvarlamadan
   dolayı küçük sapmalar oluşabilir.

3. Öncelik Bağışı ile Etkileşim: MLFQS aktifken öncelik bağışı tamamen
   devre dışıdır. Gerçek sistemlerde bu ikisi birlikte kullanılabilmelidir.

İyileştirme Önerileri:

1. 64 Ayrı Kuyruk Kullanımı: Her öncelik seviyesi için ayrı bir liste
   tutulsa, zamanlama kararı O(1) olur (64 kuyruğun başına bakmak
   yeterlidir). ready_list üzerindeki O(log n) list_insert_ordered
   çağrısı ortadan kalkar.

2. Lazy Öncelik Hesaplama: Öncelikler yalnızca thread zamanlanmaya hazır
   olduğunda (unblock sırasında) hesaplansa, bloklu thread'ler için
   boşuna işlem yapılmaz.

3. Atomik thread_set_priority: intr_disable()/intr_enable() eklenerek
   yukarıda B6'da tanımlanan ince yarış koşulu tamamen kapatılabilir.


>> C6: Görev, sabit nokta matematiği için ayrıntılı aritmetiği açıklasa da,
>>     bunu nasıl uygulayacağınız konusunda size açık bir yön bırakmaktadır.
>>     Bunu yaptığınız şekilde uygulamaya karar vermenizin nedeni nedir?
>>     Sabit nokta matematiği için bir soyutlama katmanı oluşturduysanız
>>     neden? Oluşturmadıysanız neden?

Seçilen Yaklaşım: thread.h dosyasında #define makro seti

Makro Tabanlı Soyutlama Katmanı Neden?

1. Sıfır Çalışma Zamanı Maliyeti: Makrolar derleme zamanında yerine
   konulur; fonksiyon çağrısı yükü yoktur. Bu, her timer tick'inde
   çağrılan hesaplamalar için kritik önem taşır.

2. Okunabilirlik: İşlemlerin isimlendirilmesi (MULTXY, DIVXY, ADDXN vb.),
   ham "(int64_t)x * y / F" ifadelerine kıyasla kodun anlaşılmasını
   kolaylaştırır ve hata riskini azaltır.

3. Tek Yer Tanım: 17.14 biçiminin ölçek faktörü F = (1 << 14) yalnızca
   bir kez tanımlanır. Biçim değiştirilmek istenirse yalnızca F makrosu
   güncellenir.

4. int64_t ile Taşma Önlemi: MULTXY ve DIVXY içinde hesaplama öncesi
   (int64_t) dönüşümü yapılır; bu sayede iki büyük sabit nokta sayısının
   çarpımında 32-bit taşması önlenir.

Alternatif — Typedef + Satır İçi Fonksiyonlar:
  fixed_t türü ve static inline fonksiyonlar kullanılabilirdi. Bu yaklaşım
  tip güvenliği sağlar (sabit nokta ve tam sayı karışmasını derleyici
  yakalar). Ancak Pintos'un C89/C99 ortamında inline fonksiyonlar
  taşınabilirlik sorununa yol açabilir ve makroların sağladığı sıfır maliyet
  garantisini verememektedir.

Neden Soyutlama Katmanı Tercih Edildi?
  Hesaplamaların birden fazla yerde (thread_tick, thread_set_nice,
  thread_get_recent_cpu, thread_get_load_avg) kullanılması, merkezi
  bir soyutlama katmanını zorunlu kılmaktadır. Bu olmadan her yerde
  F sabit değeri ve uzun aritmetik ifadeler tekrarlanır, hem bakım
  güçleşir hem de hata olasılığı artar.
